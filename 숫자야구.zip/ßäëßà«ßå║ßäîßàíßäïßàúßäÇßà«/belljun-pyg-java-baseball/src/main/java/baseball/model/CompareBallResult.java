package baseball.model;

public enum CompareBallResult {
    STRIKE,
    BALL,
    MISS
}
