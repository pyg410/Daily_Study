package baseball.view.utils.line;

@FunctionalInterface
public interface Line {
    String value();
}
